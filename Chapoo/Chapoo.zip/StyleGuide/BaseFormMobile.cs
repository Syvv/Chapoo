﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StyleGuide
{
    public partial class BaseFormMobile : Form
    {
        public BaseFormMobile()
        {
            InitializeComponent();
            pnlMain.BackColor = Color.FromArgb(245, 239, 237);
        }

        private void BaseForm_Load(object sender, EventArgs e)
        {

        }

        private void btnMenuOpnemn_Click(object sender, EventArgs e)
        {

        }

        private void txtTafel_Click(object sender, EventArgs e)
        {

        }

        private void btnMenuOpnemen_Click(object sender, EventArgs e)
        {

        }
    }
}
