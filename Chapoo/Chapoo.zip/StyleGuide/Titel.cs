﻿using System.Windows.Forms;
using System.Drawing;

namespace StyleGuide
{
    public class Titel : Label
    {
        public Titel()
        {
            Font = new Font("Arial", 20, FontStyle.Regular);
        }
    }
}