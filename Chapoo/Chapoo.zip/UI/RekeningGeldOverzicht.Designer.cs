﻿namespace UI
{
    partial class RekeningGeldOverzicht
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBtw9 = new System.Windows.Forms.Label();
            this.LblBtw21 = new System.Windows.Forms.Label();
            this.LblTotaalBedrag = new System.Windows.Forms.Label();
            this.OutBtw6 = new System.Windows.Forms.Label();
            this.OutBtw21 = new System.Windows.Forms.Label();
            this.OutTotaalBedrag = new System.Windows.Forms.Label();
            this.LblFooi = new System.Windows.Forms.Label();
            this.OutFooi = new System.Windows.Forms.Label();
            this.BtnOpmerking = new System.Windows.Forms.Button();
            this.BtnFooi = new System.Windows.Forms.Button();
            this.lblOpmerking = new System.Windows.Forms.Label();
            this.OutOpmerking = new System.Windows.Forms.Label();
            this.BtnCreditcard = new System.Windows.Forms.Button();
            this.BtnContant = new System.Windows.Forms.Button();
            this.BtnPin = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblBtw9
            // 
            this.lblBtw9.AutoSize = true;
            this.lblBtw9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBtw9.Location = new System.Drawing.Point(22, 14);
            this.lblBtw9.Name = "lblBtw9";
            this.lblBtw9.Size = new System.Drawing.Size(72, 20);
            this.lblBtw9.TabIndex = 0;
            this.lblBtw9.Text = "Btw  9%";
            // 
            // LblBtw21
            // 
            this.LblBtw21.AutoSize = true;
            this.LblBtw21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblBtw21.Location = new System.Drawing.Point(22, 41);
            this.LblBtw21.Name = "LblBtw21";
            this.LblBtw21.Size = new System.Drawing.Size(76, 20);
            this.LblBtw21.TabIndex = 1;
            this.LblBtw21.Text = "Btw 21%";
            // 
            // LblTotaalBedrag
            // 
            this.LblTotaalBedrag.AutoSize = true;
            this.LblTotaalBedrag.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTotaalBedrag.Location = new System.Drawing.Point(22, 106);
            this.LblTotaalBedrag.Name = "LblTotaalBedrag";
            this.LblTotaalBedrag.Size = new System.Drawing.Size(106, 20);
            this.LblTotaalBedrag.TabIndex = 2;
            this.LblTotaalBedrag.Text = "Totaalbedrag";
            // 
            // OutBtw6
            // 
            this.OutBtw6.AutoSize = true;
            this.OutBtw6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OutBtw6.Location = new System.Drawing.Point(160, 14);
            this.OutBtw6.Name = "OutBtw6";
            this.OutBtw6.Size = new System.Drawing.Size(54, 20);
            this.OutBtw6.TabIndex = 3;
            this.OutBtw6.Text = "€ 0.00";
            // 
            // OutBtw21
            // 
            this.OutBtw21.AutoSize = true;
            this.OutBtw21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OutBtw21.Location = new System.Drawing.Point(160, 41);
            this.OutBtw21.Name = "OutBtw21";
            this.OutBtw21.Size = new System.Drawing.Size(54, 20);
            this.OutBtw21.TabIndex = 4;
            this.OutBtw21.Text = "€ 0.00";
            // 
            // OutTotaalBedrag
            // 
            this.OutTotaalBedrag.AutoSize = true;
            this.OutTotaalBedrag.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OutTotaalBedrag.Location = new System.Drawing.Point(160, 105);
            this.OutTotaalBedrag.Name = "OutTotaalBedrag";
            this.OutTotaalBedrag.Size = new System.Drawing.Size(54, 20);
            this.OutTotaalBedrag.TabIndex = 5;
            this.OutTotaalBedrag.Text = "€ 0.00";
            // 
            // LblFooi
            // 
            this.LblFooi.AutoSize = true;
            this.LblFooi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblFooi.Location = new System.Drawing.Point(22, 67);
            this.LblFooi.Name = "LblFooi";
            this.LblFooi.Size = new System.Drawing.Size(41, 20);
            this.LblFooi.TabIndex = 6;
            this.LblFooi.Text = "Fooi";
            // 
            // OutFooi
            // 
            this.OutFooi.AutoSize = true;
            this.OutFooi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OutFooi.Location = new System.Drawing.Point(160, 67);
            this.OutFooi.Name = "OutFooi";
            this.OutFooi.Size = new System.Drawing.Size(54, 20);
            this.OutFooi.TabIndex = 7;
            this.OutFooi.Text = "€ 0.00";
            // 
            // BtnOpmerking
            // 
            this.BtnOpmerking.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnOpmerking.Location = new System.Drawing.Point(407, 14);
            this.BtnOpmerking.Name = "BtnOpmerking";
            this.BtnOpmerking.Size = new System.Drawing.Size(132, 44);
            this.BtnOpmerking.TabIndex = 8;
            this.BtnOpmerking.Text = "Opmerking";
            this.BtnOpmerking.UseVisualStyleBackColor = true;
            this.BtnOpmerking.Click += new System.EventHandler(this.BtnOpmerking_Click);
            // 
            // BtnFooi
            // 
            this.BtnFooi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnFooi.Location = new System.Drawing.Point(407, 78);
            this.BtnFooi.Name = "BtnFooi";
            this.BtnFooi.Size = new System.Drawing.Size(132, 44);
            this.BtnFooi.TabIndex = 9;
            this.BtnFooi.Text = "Fooi";
            this.BtnFooi.UseVisualStyleBackColor = true;
            this.BtnFooi.Click += new System.EventHandler(this.BtnFooi_Click);
            // 
            // lblOpmerking
            // 
            this.lblOpmerking.AutoSize = true;
            this.lblOpmerking.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOpmerking.Location = new System.Drawing.Point(22, 154);
            this.lblOpmerking.Name = "lblOpmerking";
            this.lblOpmerking.Size = new System.Drawing.Size(90, 20);
            this.lblOpmerking.TabIndex = 10;
            this.lblOpmerking.Text = "Opmerking";
            // 
            // OutOpmerking
            // 
            this.OutOpmerking.AutoSize = true;
            this.OutOpmerking.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OutOpmerking.Location = new System.Drawing.Point(160, 154);
            this.OutOpmerking.Name = "OutOpmerking";
            this.OutOpmerking.Size = new System.Drawing.Size(17, 20);
            this.OutOpmerking.TabIndex = 11;
            this.OutOpmerking.Text = "x";
            // 
            // BtnCreditcard
            // 
            this.BtnCreditcard.Location = new System.Drawing.Point(402, 212);
            this.BtnCreditcard.Name = "BtnCreditcard";
            this.BtnCreditcard.Size = new System.Drawing.Size(151, 39);
            this.BtnCreditcard.TabIndex = 14;
            this.BtnCreditcard.Text = "Creditcard";
            this.BtnCreditcard.UseVisualStyleBackColor = true;
            this.BtnCreditcard.Click += new System.EventHandler(this.BtnCreditcard_Click);
            // 
            // BtnContant
            // 
            this.BtnContant.Location = new System.Drawing.Point(215, 212);
            this.BtnContant.Name = "BtnContant";
            this.BtnContant.Size = new System.Drawing.Size(151, 39);
            this.BtnContant.TabIndex = 13;
            this.BtnContant.Text = "Cash / contant";
            this.BtnContant.UseVisualStyleBackColor = true;
            this.BtnContant.Click += new System.EventHandler(this.BtnContant_Click);
            // 
            // BtnPin
            // 
            this.BtnPin.Location = new System.Drawing.Point(26, 212);
            this.BtnPin.Name = "BtnPin";
            this.BtnPin.Size = new System.Drawing.Size(151, 39);
            this.BtnPin.TabIndex = 12;
            this.BtnPin.Text = "Pin";
            this.BtnPin.UseVisualStyleBackColor = true;
            this.BtnPin.Click += new System.EventHandler(this.BtnPin_Click);
            // 
            // RekeningGeldOverzicht
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.BtnCreditcard);
            this.Controls.Add(this.BtnContant);
            this.Controls.Add(this.BtnPin);
            this.Controls.Add(this.OutOpmerking);
            this.Controls.Add(this.lblOpmerking);
            this.Controls.Add(this.BtnFooi);
            this.Controls.Add(this.BtnOpmerking);
            this.Controls.Add(this.OutFooi);
            this.Controls.Add(this.LblFooi);
            this.Controls.Add(this.OutTotaalBedrag);
            this.Controls.Add(this.OutBtw21);
            this.Controls.Add(this.OutBtw6);
            this.Controls.Add(this.LblTotaalBedrag);
            this.Controls.Add(this.LblBtw21);
            this.Controls.Add(this.lblBtw9);
            this.Name = "RekeningGeldOverzicht";
            this.Size = new System.Drawing.Size(584, 276);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBtw9;
        private System.Windows.Forms.Label LblBtw21;
        private System.Windows.Forms.Label LblTotaalBedrag;
        private System.Windows.Forms.Label OutBtw6;
        private System.Windows.Forms.Label OutBtw21;
        private System.Windows.Forms.Label OutTotaalBedrag;
        private System.Windows.Forms.Label LblFooi;
        private System.Windows.Forms.Label OutFooi;
        private System.Windows.Forms.Button BtnOpmerking;
        private System.Windows.Forms.Button BtnFooi;
        private System.Windows.Forms.Label lblOpmerking;
        private System.Windows.Forms.Label OutOpmerking;
        private System.Windows.Forms.Button BtnCreditcard;
        private System.Windows.Forms.Button BtnContant;
        private System.Windows.Forms.Button BtnPin;
    }
}
