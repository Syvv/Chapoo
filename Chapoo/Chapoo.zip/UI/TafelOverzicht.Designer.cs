﻿namespace UI
{
    partial class TafelOverzicht
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TafelOverzicht));
            this.tafelButton7 = new StyleGuide.TafelButton();
            this.tafelButton8 = new StyleGuide.TafelButton();
            this.tafelButton9 = new StyleGuide.TafelButton();
            this.tafelButton10 = new StyleGuide.TafelButton();
            this.tafelButton6 = new StyleGuide.TafelButton();
            this.tafelButton5 = new StyleGuide.TafelButton();
            this.tafelButton4 = new StyleGuide.TafelButton();
            this.tafelButton3 = new StyleGuide.TafelButton();
            this.tafelButton2 = new StyleGuide.TafelButton();
            this.tafelButton1 = new StyleGuide.TafelButton();
            this.titel = new StyleGuide.Titel();
            this.uitlogButton1 = new StyleGuide.UitlogButton();
            this.SuspendLayout();
            // 
            // tafelButton7
            // 
            this.tafelButton7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tafelButton7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tafelButton7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.tafelButton7.Location = new System.Drawing.Point(113, 518);
            this.tafelButton7.Margin = new System.Windows.Forms.Padding(4);
            this.tafelButton7.Name = "tafelButton7";
            this.tafelButton7.Size = new System.Drawing.Size(133, 123);
            this.tafelButton7.TabIndex = 20;
            this.tafelButton7.Text = "7";
            this.tafelButton7.UseVisualStyleBackColor = true;
            this.tafelButton7.Click += new System.EventHandler(this.tafelButton7_Click);
            // 
            // tafelButton8
            // 
            this.tafelButton8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tafelButton8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tafelButton8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.tafelButton8.Location = new System.Drawing.Point(334, 518);
            this.tafelButton8.Margin = new System.Windows.Forms.Padding(4);
            this.tafelButton8.Name = "tafelButton8";
            this.tafelButton8.Size = new System.Drawing.Size(133, 123);
            this.tafelButton8.TabIndex = 19;
            this.tafelButton8.Text = "8";
            this.tafelButton8.UseVisualStyleBackColor = true;
            this.tafelButton8.Click += new System.EventHandler(this.tafelButton8_Click);
            // 
            // tafelButton9
            // 
            this.tafelButton9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tafelButton9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tafelButton9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.tafelButton9.Location = new System.Drawing.Point(113, 649);
            this.tafelButton9.Margin = new System.Windows.Forms.Padding(4);
            this.tafelButton9.Name = "tafelButton9";
            this.tafelButton9.Size = new System.Drawing.Size(133, 123);
            this.tafelButton9.TabIndex = 18;
            this.tafelButton9.Text = "9";
            this.tafelButton9.UseVisualStyleBackColor = true;
            this.tafelButton9.Click += new System.EventHandler(this.tafelButton9_Click);
            // 
            // tafelButton10
            // 
            this.tafelButton10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tafelButton10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tafelButton10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.tafelButton10.Location = new System.Drawing.Point(334, 649);
            this.tafelButton10.Margin = new System.Windows.Forms.Padding(4);
            this.tafelButton10.Name = "tafelButton10";
            this.tafelButton10.Size = new System.Drawing.Size(133, 123);
            this.tafelButton10.TabIndex = 17;
            this.tafelButton10.Text = "10";
            this.tafelButton10.UseVisualStyleBackColor = true;
            this.tafelButton10.Click += new System.EventHandler(this.tafelButton10_Click);
            // 
            // tafelButton6
            // 
            this.tafelButton6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tafelButton6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tafelButton6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.tafelButton6.Location = new System.Drawing.Point(334, 388);
            this.tafelButton6.Margin = new System.Windows.Forms.Padding(4);
            this.tafelButton6.Name = "tafelButton6";
            this.tafelButton6.Size = new System.Drawing.Size(133, 123);
            this.tafelButton6.TabIndex = 16;
            this.tafelButton6.Text = "6";
            this.tafelButton6.UseVisualStyleBackColor = true;
            this.tafelButton6.Click += new System.EventHandler(this.tafelButton6_Click);
            // 
            // tafelButton5
            // 
            this.tafelButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tafelButton5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tafelButton5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.tafelButton5.Location = new System.Drawing.Point(113, 388);
            this.tafelButton5.Margin = new System.Windows.Forms.Padding(4);
            this.tafelButton5.Name = "tafelButton5";
            this.tafelButton5.Size = new System.Drawing.Size(133, 123);
            this.tafelButton5.TabIndex = 15;
            this.tafelButton5.Text = "5";
            this.tafelButton5.UseVisualStyleBackColor = true;
            this.tafelButton5.Click += new System.EventHandler(this.tafelButton5_Click);
            // 
            // tafelButton4
            // 
            this.tafelButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tafelButton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tafelButton4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.tafelButton4.Location = new System.Drawing.Point(334, 257);
            this.tafelButton4.Margin = new System.Windows.Forms.Padding(4);
            this.tafelButton4.Name = "tafelButton4";
            this.tafelButton4.Size = new System.Drawing.Size(133, 123);
            this.tafelButton4.TabIndex = 14;
            this.tafelButton4.Text = "4";
            this.tafelButton4.UseVisualStyleBackColor = true;
            this.tafelButton4.Click += new System.EventHandler(this.tafelButton4_Click);
            // 
            // tafelButton3
            // 
            this.tafelButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tafelButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tafelButton3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.tafelButton3.Location = new System.Drawing.Point(113, 257);
            this.tafelButton3.Margin = new System.Windows.Forms.Padding(4);
            this.tafelButton3.Name = "tafelButton3";
            this.tafelButton3.Size = new System.Drawing.Size(133, 123);
            this.tafelButton3.TabIndex = 13;
            this.tafelButton3.Text = "3";
            this.tafelButton3.UseVisualStyleBackColor = true;
            this.tafelButton3.Click += new System.EventHandler(this.tafelButton3_Click);
            // 
            // tafelButton2
            // 
            this.tafelButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tafelButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tafelButton2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.tafelButton2.Location = new System.Drawing.Point(334, 127);
            this.tafelButton2.Margin = new System.Windows.Forms.Padding(4);
            this.tafelButton2.Name = "tafelButton2";
            this.tafelButton2.Size = new System.Drawing.Size(133, 123);
            this.tafelButton2.TabIndex = 12;
            this.tafelButton2.Text = "2";
            this.tafelButton2.UseVisualStyleBackColor = true;
            this.tafelButton2.Click += new System.EventHandler(this.tafelButton2_Click_1);
            // 
            // tafelButton1
            // 
            this.tafelButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tafelButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tafelButton1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.tafelButton1.Location = new System.Drawing.Point(113, 127);
            this.tafelButton1.Margin = new System.Windows.Forms.Padding(4);
            this.tafelButton1.Name = "tafelButton1";
            this.tafelButton1.Size = new System.Drawing.Size(133, 123);
            this.tafelButton1.TabIndex = 11;
            this.tafelButton1.Text = "1";
            this.tafelButton1.UseVisualStyleBackColor = true;
            this.tafelButton1.Click += new System.EventHandler(this.tafelButton1_Click);
            // 
            // titel
            // 
            this.titel.AutoSize = true;
            this.titel.Font = new System.Drawing.Font("Arial", 20F);
            this.titel.Location = new System.Drawing.Point(78, 25);
            this.titel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.titel.Name = "titel";
            this.titel.Size = new System.Drawing.Size(86, 39);
            this.titel.TabIndex = 10;
            this.titel.Text = "titel1";
            // 
            // uitlogButton1
            // 
            this.uitlogButton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("uitlogButton1.BackgroundImage")));
            this.uitlogButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.uitlogButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.uitlogButton1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uitlogButton1.Location = new System.Drawing.Point(430, 25);
            this.uitlogButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.uitlogButton1.Name = "uitlogButton1";
            this.uitlogButton1.Size = new System.Drawing.Size(71, 59);
            this.uitlogButton1.TabIndex = 9;
            this.uitlogButton1.UseVisualStyleBackColor = true;
            this.uitlogButton1.Click += new System.EventHandler(this.uitlogButton1_Click);
            // 
            // TafelOverzicht
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(581, 853);
            this.Controls.Add(this.tafelButton7);
            this.Controls.Add(this.tafelButton8);
            this.Controls.Add(this.tafelButton9);
            this.Controls.Add(this.tafelButton10);
            this.Controls.Add(this.tafelButton6);
            this.Controls.Add(this.tafelButton5);
            this.Controls.Add(this.tafelButton4);
            this.Controls.Add(this.tafelButton3);
            this.Controls.Add(this.tafelButton2);
            this.Controls.Add(this.tafelButton1);
            this.Controls.Add(this.titel);
            this.Controls.Add(this.uitlogButton1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "TafelOverzicht";
            this.Text = "TafelOverzicht";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        protected StyleGuide.UitlogButton uitlogButton1;
        private StyleGuide.Titel titel;
        private StyleGuide.TafelButton tafelButton1;
        private StyleGuide.TafelButton tafelButton2;
        private StyleGuide.TafelButton tafelButton3;
        private StyleGuide.TafelButton tafelButton4;
        private StyleGuide.TafelButton tafelButton5;
        private StyleGuide.TafelButton tafelButton6;
        private StyleGuide.TafelButton tafelButton7;
        private StyleGuide.TafelButton tafelButton8;
        private StyleGuide.TafelButton tafelButton9;
        private StyleGuide.TafelButton tafelButton10;
    }
}